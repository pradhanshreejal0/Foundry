import { useState, useEffect, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Pencil, Trash2, Plus } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { api } from "@/lib/api";
import ImageUploader from "@/components/admin/ImageUploader";

export default function Ads() {
  const [ads, setAds] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingAd, setEditingAd] = useState(null);
  const [saving, setSaving] = useState(false);
  const saveLockRef = useRef(false);
  const deleteLockRef = useRef(new Set());
  const [formData, setFormData] = useState({
    title: "",
    image: "",
    link: "",
    position: "homepage",
    isActive: true,
  });
  const { accessToken } = useAuth();

  useEffect(() => {
    if (!accessToken) return;

    let cancelled = false;

    const loadAds = async () => {
      try {
        const data = await api("/ads", { accessToken });
        if (!cancelled) {
          setAds(data);
          setError("");
        }
      } catch (err) {
        if (!cancelled) {
          setError(err.message || "Failed to load ads");
        }
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    };

    loadAds();

    return () => {
      cancelled = true;
    };
  }, [accessToken]);

  const openCreateDialog = () => {
    setEditingAd(null);
    setFormData({
      title: "",
      image: "",
      link: "",
      position: "homepage",
      isActive: true,
    });
    setError("");
    setDialogOpen(true);
  };

  const openEditDialog = (ad) => {
    setEditingAd(ad);
    setFormData({
      title: ad.title,
      image: ad.image,
      link: ad.link || "",
      position: ad.position,
      isActive: ad.isActive,
    });
    setError("");
    setDialogOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (saveLockRef.current || saving) return;
    setError("");

    if (!formData.image) {
      setError("Please upload an image");
      return;
    }

    saveLockRef.current = true;
    setSaving(true);
    try {
      if (editingAd) {
        await api(`/ads/${editingAd._id}`, {
          method: "PUT",
          accessToken,
          body: JSON.stringify(formData),
        });
      } else {
        await api("/ads", {
          method: "POST",
          accessToken,
          body: JSON.stringify(formData),
        });
      }
      setDialogOpen(false);

      const data = await api("/ads", { accessToken });
      setAds(data);
    } catch (err) {
      setError(err.message || "Something went wrong");
    } finally {
      saveLockRef.current = false;
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    if (deleteLockRef.current.has(id)) return;
    deleteLockRef.current.add(id);
    try {
      await api(`/ads/${id}`, {
        method: "DELETE",
        accessToken,
      });
      setAds((prev) => prev.filter((ad) => ad._id !== id));
    } catch (err) {
      setError(err.message || "Failed to delete ad");
    } finally {
      deleteLockRef.current.delete(id);
    }
  };

  if (loading) {
    return <p className="text-muted-foreground">Loading ads...</p>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Ads & Banners</h1>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button onClick={openCreateDialog}>
              <Plus className="h-4 w-4 mr-2" />
              Add Ad
            </Button>
          </DialogTrigger>
          <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
            <DialogHeader>
              <DialogTitle>
                {editingAd ? "Edit Ad" : "New Ad / Banner"}
              </DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="title">Title</Label>
                <Input
                  id="title"
                  value={formData.title}
                  onChange={(e) =>
                    setFormData({ ...formData, title: e.target.value })
                  }
                  required
                />
              </div>

              {/* Image Upload */}
              <div className="space-y-2">
                <Label>Image</Label>
                <ImageUploader
                  onUpload={(url) =>
                    setFormData({ ...formData, image: url })
                  }
                  imageUrl={formData.image}
                  label="Upload Ad Image"
                  accessToken={accessToken}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="link">Link (optional)</Label>
                <Input
                  id="link"
                  value={formData.link}
                  onChange={(e) =>
                    setFormData({ ...formData, link: e.target.value })
                  }
                  placeholder="/products or https://..."
                />
              </div>

              <div className="space-y-2">
                <Label>Position</Label>
                <Select
                  value={formData.position}
                  onValueChange={(value) =>
                    setFormData({ ...formData, position: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="homepage">Homepage</SelectItem>
                    <SelectItem value="sidebar">Sidebar</SelectItem>
                    <SelectItem value="category">Category Page</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Status</Label>
                <Select
                  value={formData.isActive ? "active" : "inactive"}
                  onValueChange={(value) =>
                    setFormData({
                      ...formData,
                      isActive: value === "active",
                    })
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {error && <p className="text-sm text-destructive">{error}</p>}

              <DialogFooter>
                <Button type="submit" disabled={saving}>
                  {saving ? "Saving..." : editingAd ? "Save" : "Create"}
                </Button>
              </DialogFooter>
            </form>
          </DialogContent>
        </Dialog>
      </div>

        <div className="overflow-x-auto rounded-xl border bg-background shadow-sm">
          <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Image</TableHead>
            <TableHead>Title</TableHead>
            <TableHead>Position</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {ads.length === 0 ? (
            <TableRow>
              <TableCell
                colSpan={5}
                className="text-center text-muted-foreground"
              >
                No ads yet. Create one to get started.
              </TableCell>
            </TableRow>
          ) : (
            ads.map((ad) => (
              <TableRow key={ad._id}>
                <TableCell>
                  <img
                    src={ad.image}
                    alt={ad.title}
                    className="h-12 w-20 rounded object-cover"
                  />
                </TableCell>
                <TableCell className="font-medium">{ad.title}</TableCell>
                <TableCell className="capitalize">{ad.position}</TableCell>
                <TableCell>
                  <Badge variant={ad.isActive ? "default" : "secondary"}>
                    {ad.isActive ? "Active" : "Inactive"}
                  </Badge>
                </TableCell>
                <TableCell className="text-right space-x-2">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => openEditDialog(ad)}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="icon">
                        <Trash2 className="h-4 w-4 text-destructive" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>
                          Delete "{ad.title}"?
                        </AlertDialogTitle>
                        <AlertDialogDescription>
                          This action cannot be undone.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction
                          onClick={() => handleDelete(ad._id)}
                        >
                          Delete
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </TableCell>
              </TableRow>
            ))
          )}
        </TableBody>
          </Table>
        </div>

      {error && !dialogOpen && (
        <p className="text-sm text-destructive mt-4">{error}</p>
      )}
    </div>
  );
}